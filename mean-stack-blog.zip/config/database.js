/**
 * Created by zohaib on 12/3/2017.
 */

const crypto = require('crypto').randomBytes(256).toString('hex');

module.exports = {
    uri     : 'mongodb://localhost:27017/mean-angular-5'/* + this.db*/,
    secret  : crypto,
    db      : 'development database: mean-angular-5',
};